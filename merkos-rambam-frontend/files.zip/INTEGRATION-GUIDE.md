# Artifact Integration Guide

## What these files are

Three rich visual artifacts to replace/supplement the content in the hero `<div class="hero__slides">` area of the player mockup. These are the content that cycles through the "album art" stage.

## Current state (v6)

The v6 mockup has 3 slides:
- Artifact 0: Mishkan image (`<img>` tag)
- Artifact 1: Temple diagram (basic SVG boxes)
- Artifact 2: Timeline with era pills (uses external images)

## What to do

### Replace Artifact 1 (Temple Diagram)

Replace the entire contents of `<div class="hero__slide hero__slide--diagram" data-artifact="1">` with the HTML from `artifact-2-temple-diagram.html`.

Keep the existing CSS for `.hero__slide--diagram` — it already handles the dark gradient background, centering, and padding.

### Add Artifact 3 (Seven Vessels)

Add a new slide after the timeline slide:

```html
<div class="hero__slide hero__slide--vessels" data-artifact="3">
  <!-- paste contents of artifact-4-seven-vessels.html -->
</div>
```

Add this CSS:
```css
.hero__slide--vessels {
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(160deg, #0d1117 0%, #10160e 50%, #0d1117 100%);
  padding: 20px;
}
```

### Add Artifact 4 (Sanctuary Journey)

Add another slide:

```html
<div class="hero__slide hero__slide--journey" data-artifact="4">
  <!-- paste contents of artifact-5-sanctuary-journey.html -->
</div>
```

Add this CSS (same pattern):
```css
.hero__slide--journey {
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(160deg, #0d1117 0%, #111820 50%, #0a1628 100%);
  padding: 20px;
}
```

### Update dots

Change the dots section to have 5 dots instead of 3:

```html
<div class="hero__dots">
  <div class="hero__dot active" data-artifact="0"></div>
  <div class="hero__dot" data-artifact="1"></div>
  <div class="hero__dot" data-artifact="2"></div>
  <div class="hero__dot" data-artifact="3"></div>
  <div class="hero__dot" data-artifact="4"></div>
</div>
```

### Update JS

The existing `goToArtifact()` function already works with `artifactSlides.length`, so it should automatically handle the new slides as long as the dots have matching `data-artifact` values.

## Design notes

- All artifacts use the same font families as the mockup: Plus Jakarta Sans for UI, DM Sans for body, Noto Sans Hebrew for Hebrew text
- Colors match the Spotify palette: #1DB954 green, #E8734A / #D85A30 coral, #5EADFF / #378ADD blue, #C5A059 gold
- All designed for dark backgrounds (#121212 base)
- Ambient glow effects are subtle radial gradients — remove them if performance is a concern
- SVG vessel icons are hand-drawn to match the style
